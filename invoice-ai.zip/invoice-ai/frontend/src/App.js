import React from 'react';
import { BrowserRouter, Routes, Route, NavLink, useLocation } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import UploadPage from './pages/UploadPage';
import InvoicesPage from './pages/InvoicesPage';
import AnalyticsPage from './pages/AnalyticsPage';
import InvoiceDetailPage from './pages/InvoiceDetailPage';
import { FileText, BarChart3, Upload, Zap, Github } from 'lucide-react';
import './App.css';

function Nav() {
  const location = useLocation();

  return (
    <nav className="app-nav">
      <div className="nav-brand">
        <div className="brand-icon">
          <Zap size={16} />
        </div>
        <span className="brand-name">InvoiceAI</span>
        <span className="brand-tag">BETA</span>
      </div>

      <div className="nav-links">
        <NavLink to="/" className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
          <Upload size={15} />
          Extract
        </NavLink>
        <NavLink to="/invoices" className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
          <FileText size={15} />
          Invoices
        </NavLink>
        <NavLink to="/analytics" className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
          <BarChart3 size={15} />
          Analytics
        </NavLink>
      </div>

      <a
        href="https://github.com/yourusername/invoice-ai"
        target="_blank"
        rel="noreferrer"
        className="nav-github"
      >
        <Github size={16} />
      </a>
    </nav>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <div className="app-shell">
        <Nav />
        <main className="app-main">
          <Routes>
            <Route path="/" element={<UploadPage />} />
            <Route path="/invoices" element={<InvoicesPage />} />
            <Route path="/invoices/:id" element={<InvoiceDetailPage />} />
            <Route path="/analytics" element={<AnalyticsPage />} />
          </Routes>
        </main>
      </div>
      <Toaster
        position="bottom-right"
        toastOptions={{
          style: {
            background: 'var(--bg-2)',
            color: 'var(--text)',
            border: '1px solid var(--border)',
            fontFamily: 'var(--font-body)',
            fontSize: '13px',
          },
          success: { iconTheme: { primary: '#10b981', secondary: 'var(--bg)' } },
          error: { iconTheme: { primary: '#ef4444', secondary: 'var(--bg)' } },
        }}
      />
    </BrowserRouter>
  );
}
