import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { getInvoice } from '../utils/api';
import { ChevronLeft, Loader2, Copy, CheckCircle } from 'lucide-react';
import './InvoiceDetailPage.css';

function Field({ label, value, mono }) {
  if (value == null || value === '') return null;
  return (
    <div className="field-row">
      <div className="field-label">{label}</div>
      <div className={`field-value ${mono ? 'mono' : ''}`}>{String(value)}</div>
    </div>
  );
}

function ConfidenceMeter({ score }) {
  const pct = Math.round((score || 0) * 100);
  const label = score >= 0.8 ? 'High' : score >= 0.6 ? 'Medium' : 'Low';
  const color = score >= 0.8 ? 'var(--green)' : score >= 0.6 ? 'var(--gold)' : 'var(--red)';
  return (
    <div className="conf-meter">
      <div className="conf-meter-track">
        <div className="conf-meter-fill" style={{ width: `${pct}%`, background: color }} />
      </div>
      <div className="conf-meter-labels">
        <span className="mono" style={{ color }}>{pct}% – {label} Confidence</span>
      </div>
    </div>
  );
}

export default function InvoiceDetailPage() {
  const { id } = useParams();
  const [invoice, setInvoice] = useState(null);
  const [loading, setLoading] = useState(true);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    getInvoice(id).then(setInvoice).finally(() => setLoading(false));
  }, [id]);

  const copyJSON = () => {
    if (!invoice) return;
    navigator.clipboard.writeText(JSON.stringify(invoice.extracted_data, null, 2));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  if (loading) return (
    <div className="detail-loading fade-in">
      <Loader2 size={28} className="spin text-accent" />
      <span className="text-dim">Loading invoice...</span>
    </div>
  );

  if (!invoice) return (
    <div className="detail-loading">
      <p className="text-dim">Invoice not found.</p>
      <Link to="/invoices" className="btn btn-ghost">Back to Invoices</Link>
    </div>
  );

  const data = typeof invoice.extracted_data === 'string'
    ? JSON.parse(invoice.extracted_data)
    : (invoice.extracted_data || {});

  const lineItems = data.line_items || [];
  const warnings = data.extraction_warnings || [];

  return (
    <div className="detail-page fade-in">
      <div className="detail-header">
        <Link to="/invoices" className="btn btn-ghost back-btn">
          <ChevronLeft size={14} /> Back
        </Link>
        <div className="detail-title-wrap">
          <h1 className="detail-title">{data.vendor_name || invoice.filename}</h1>
          <div className="detail-id mono">{invoice.id}</div>
        </div>
        <button className="btn btn-ghost" onClick={copyJSON}>
          {copied ? <CheckCircle size={14} className="text-green" /> : <Copy size={14} />}
          {copied ? 'Copied!' : 'Copy JSON'}
        </button>
      </div>

      {invoice.is_duplicate && (
        <div className="dup-banner">
          ⚠️ This is a duplicate invoice — originally processed as{' '}
          <Link to={`/invoices/${invoice.duplicate_of}`} className="text-accent">
            {invoice.duplicate_of}
          </Link>
        </div>
      )}

      {warnings.length > 0 && (
        <div className="warnings-box">
          <div className="warnings-title">Extraction Warnings</div>
          {warnings.map((w, i) => <div key={i} className="warning-item">⚠ {w}</div>)}
        </div>
      )}

      <ConfidenceMeter score={data.confidence_score} />

      <div className="detail-grid">
        {/* Invoice Details */}
        <div className="card detail-card">
          <div className="card-header">Invoice Details</div>
          <Field label="Invoice Number" value={data.invoice_number} mono />
          <Field label="Invoice Date" value={data.invoice_date} />
          <Field label="Due Date" value={data.due_date} />
          <Field label="Payment Terms" value={data.payment_terms} />
          <Field label="Currency" value={data.currency} mono />
          <Field label="Notes" value={data.notes} />
        </div>

        {/* Vendor */}
        <div className="card detail-card">
          <div className="card-header">Vendor</div>
          <Field label="Name" value={data.vendor_name} />
          <Field label="Address" value={data.vendor_address} />
          <Field label="Email" value={data.vendor_email} mono />
          <Field label="Phone" value={data.vendor_phone} mono />
        </div>

        {/* Client */}
        <div className="card detail-card">
          <div className="card-header">Billed To</div>
          <Field label="Name" value={data.client_name} />
          <Field label="Address" value={data.client_address} />
        </div>

        {/* Financials */}
        <div className="card detail-card">
          <div className="card-header">Financials</div>
          <Field label="Subtotal" value={data.subtotal != null ? `${data.currency} ${Number(data.subtotal).toLocaleString(undefined, {minimumFractionDigits:2})}` : null} mono />
          <Field label="Tax Rate" value={data.tax_rate != null ? `${data.tax_rate}%` : null} mono />
          <Field label="Tax Amount" value={data.tax_amount != null ? `${data.currency} ${Number(data.tax_amount).toLocaleString(undefined, {minimumFractionDigits:2})}` : null} mono />
          <Field label="Discount" value={data.discount != null ? `${data.currency} ${Number(data.discount).toLocaleString(undefined, {minimumFractionDigits:2})}` : null} mono />
          <div className="total-row">
            <div className="field-label">Total Amount</div>
            <div className="total-value mono">
              {data.currency} {data.total_amount != null ? Number(data.total_amount).toLocaleString(undefined, {minimumFractionDigits:2}) : '—'}
            </div>
          </div>
        </div>
      </div>

      {/* Line Items */}
      {lineItems.length > 0 && (
        <div className="card line-items-card">
          <div className="card-header">Line Items ({lineItems.length})</div>
          <div className="line-items-table-wrap">
            <table className="line-items-table">
              <thead>
                <tr>
                  <th>Description</th>
                  <th>Qty</th>
                  <th>Unit Price</th>
                  <th>Amount</th>
                </tr>
              </thead>
              <tbody>
                {lineItems.map((item, i) => (
                  <tr key={i}>
                    <td>{item.description}</td>
                    <td className="mono">{item.quantity ?? '—'}</td>
                    <td className="mono">{item.unit_price != null ? `${data.currency} ${Number(item.unit_price).toFixed(2)}` : '—'}</td>
                    <td className="mono amount-col">{item.amount != null ? `${data.currency} ${Number(item.amount).toFixed(2)}` : '—'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Raw JSON */}
      <div className="card raw-json-card">
        <div className="card-header">Raw Extracted JSON</div>
        <pre className="raw-json mono">{JSON.stringify(data, null, 2)}</pre>
      </div>

      <div className="detail-meta">
        <span className="text-dim mono">Processed: {new Date(invoice.created_at).toLocaleString()}</span>
        {invoice.processing_time_ms && (
          <span className="text-dim mono">· {invoice.processing_time_ms}ms</span>
        )}
        {invoice.format_signature && (
          <span className="badge badge-info">Template: {invoice.format_signature}</span>
        )}
      </div>
    </div>
  );
}
