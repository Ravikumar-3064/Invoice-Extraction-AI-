import React, { useState, useEffect } from 'react';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  LineChart, Line, PieChart, Pie, Cell, Legend, Area, AreaChart
} from 'recharts';
import { getAnalytics } from '../utils/api';
import { TrendingUp, FileText, DollarSign, Globe, Loader2 } from 'lucide-react';
import './AnalyticsPage.css';

const COLORS = ['#6366f1', '#8b5cf6', '#ec4899', '#f59e0b', '#10b981', '#3b82f6', '#ef4444'];

const CustomTooltip = ({ active, payload, label }) => {
  if (active && payload && payload.length) {
    return (
      <div className="custom-tooltip">
        <div className="tooltip-label">{label}</div>
        {payload.map((p, i) => (
          <div key={i} className="tooltip-value mono" style={{ color: p.color }}>
            {p.name}: {typeof p.value === 'number' ? p.value.toLocaleString(undefined, { minimumFractionDigits: 2 }) : p.value}
          </div>
        ))}
      </div>
    );
  }
  return null;
};

function StatCard({ icon, label, value, sub, color }) {
  return (
    <div className="stat-card card">
      <div className="stat-icon" style={{ color, background: `${color}18` }}>
        {icon}
      </div>
      <div className="stat-value">{value}</div>
      <div className="stat-label">{label}</div>
      {sub && <div className="stat-sub">{sub}</div>}
    </div>
  );
}

export default function AnalyticsPage() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getAnalytics().then(setData).finally(() => setLoading(false));
  }, []);

  if (loading) return (
    <div className="analytics-loading fade-in">
      <Loader2 size={28} className="spin text-accent" />
      <span className="text-dim">Computing analytics...</span>
    </div>
  );

  if (!data) return <div className="analytics-loading"><p className="text-dim">Failed to load analytics</p></div>;

  const s = data.summary || {};
  const vendors = data.vendor_spend || [];
  const monthly = data.monthly_trend || [];
  const currencies = data.currency_totals || [];

  const formatAmount = (v) => {
    if (v >= 1000000) return `$${(v / 1000000).toFixed(1)}M`;
    if (v >= 1000) return `$${(v / 1000).toFixed(1)}K`;
    return `$${v.toFixed(0)}`;
  };

  return (
    <div className="analytics-page fade-in">
      <div className="analytics-header">
        <div>
          <h1 className="page-title">Analytics</h1>
          <p className="page-sub">Insights across {s.total_invoices_processed || 0} processed invoices</p>
        </div>
        <div className="analytics-updated mono text-dim">
          Updated: {new Date(data.generated_at).toLocaleTimeString()}
        </div>
      </div>

      {/* Stat Cards */}
      <div className="stats-grid">
        <StatCard
          icon={<FileText size={20} />}
          label="Invoices Processed"
          value={(s.total_invoices_processed || 0).toLocaleString()}
          color="#6366f1"
        />
        <StatCard
          icon={<DollarSign size={20} />}
          label="Total Value"
          value={formatAmount(s.total_value_usd || 0)}
          sub="USD equivalent"
          color="#10b981"
        />
        <StatCard
          icon={<TrendingUp size={20} />}
          label="Avg Confidence"
          value={`${Math.round((s.average_confidence_score || 0) * 100)}%`}
          sub="Extraction quality"
          color="#f59e0b"
        />
        <StatCard
          icon={<Globe size={20} />}
          label="Unique Vendors"
          value={(s.unique_vendors || 0).toLocaleString()}
          sub={`${(s.currencies_detected || []).join(', ') || '—'} detected`}
          color="#ec4899"
        />
      </div>

      <div className="charts-grid">
        {/* Monthly Trend */}
        {monthly.length > 0 && (
          <div className="card chart-card chart-wide">
            <div className="chart-title">Monthly Spend Trend</div>
            <ResponsiveContainer width="100%" height={220}>
              <AreaChart data={monthly} margin={{ top: 10, right: 16, left: 0, bottom: 0 }}>
                <defs>
                  <linearGradient id="areaGrad" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#6366f1" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#6366f1" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
                <XAxis dataKey="month" tick={{ fill: '#8b8fa8', fontSize: 11, fontFamily: 'DM Mono' }} />
                <YAxis tickFormatter={formatAmount} tick={{ fill: '#8b8fa8', fontSize: 11, fontFamily: 'DM Mono' }} />
                <Tooltip content={<CustomTooltip />} />
                <Area
                  type="monotone"
                  dataKey="total_amount"
                  name="Total"
                  stroke="#6366f1"
                  strokeWidth={2}
                  fill="url(#areaGrad)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        )}

        {/* Vendor Spend */}
        {vendors.length > 0 && (
          <div className="card chart-card chart-wide">
            <div className="chart-title">Top Vendors by Spend</div>
            <ResponsiveContainer width="100%" height={220}>
              <BarChart data={vendors.slice(0, 8)} layout="vertical" margin={{ top: 4, right: 20, left: 10, bottom: 4 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" horizontal={false} />
                <XAxis type="number" tickFormatter={formatAmount} tick={{ fill: '#8b8fa8', fontSize: 11, fontFamily: 'DM Mono' }} />
                <YAxis type="category" dataKey="vendor" width={120} tick={{ fill: '#8b8fa8', fontSize: 11, fontFamily: 'DM Mono' }} />
                <Tooltip content={<CustomTooltip />} />
                <Bar dataKey="total_amount" name="Total Spend" radius={[0, 4, 4, 0]}>
                  {vendors.slice(0, 8).map((_, i) => (
                    <Cell key={i} fill={COLORS[i % COLORS.length]} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        )}

        {/* Currency Breakdown */}
        {currencies.length > 0 && (
          <div className="card chart-card">
            <div className="chart-title">Currency Distribution</div>
            <ResponsiveContainer width="100%" height={220}>
              <PieChart>
                <Pie
                  data={currencies}
                  dataKey="total_amount"
                  nameKey="currency"
                  cx="50%"
                  cy="50%"
                  outerRadius={80}
                  label={({ currency, percent }) => `${currency} ${(percent * 100).toFixed(0)}%`}
                  labelLine={false}
                >
                  {currencies.map((_, i) => (
                    <Cell key={i} fill={COLORS[i % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip content={<CustomTooltip />} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        )}

        {/* Vendor Table */}
        {vendors.length > 0 && (
          <div className="card chart-card">
            <div className="chart-title">Vendor Breakdown</div>
            <div className="vendor-table">
              {vendors.map((v, i) => (
                <div key={i} className="vendor-table-row">
                  <div className="vendor-table-rank mono">{String(i + 1).padStart(2, '0')}</div>
                  <div className="vendor-table-name">{v.vendor}</div>
                  <div className="vendor-table-amount mono">
                    {Number(v.total_amount).toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {vendors.length === 0 && monthly.length === 0 && (
        <div className="analytics-empty">
          <BarChart size={40} className="text-dim" />
          <p className="text-dim">No data yet. Upload and extract some invoices to see analytics.</p>
          <a href="/" className="btn btn-primary" style={{ marginTop: 16 }}>Extract Invoices</a>
        </div>
      )}
    </div>
  );
}
