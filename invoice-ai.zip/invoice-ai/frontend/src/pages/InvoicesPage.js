import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { getInvoices } from '../utils/api';
import { FileText, ChevronRight, Search, AlertTriangle, Loader2 } from 'lucide-react';
import './InvoicesPage.css';

function ConfidenceBar({ score }) {
  const pct = Math.round((score || 0) * 100);
  const color = score >= 0.8 ? 'var(--green)' : score >= 0.6 ? 'var(--gold)' : 'var(--red)';
  return (
    <div className="conf-bar-wrap" title={`${pct}% confidence`}>
      <div className="conf-bar" style={{ width: `${pct}%`, background: color }} />
      <span className="conf-label">{pct}%</span>
    </div>
  );
}

export default function InvoicesPage() {
  const [invoices, setInvoices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [currencyFilter, setCurrencyFilter] = useState('');

  useEffect(() => {
    getInvoices().then(d => setInvoices(d.invoices || [])).finally(() => setLoading(false));
  }, []);

  const currencies = [...new Set(invoices.map(i => i.currency).filter(Boolean))];

  const filtered = invoices.filter(inv => {
    const q = search.toLowerCase();
    const matchSearch = !q ||
      (inv.vendor_name || '').toLowerCase().includes(q) ||
      (inv.filename || '').toLowerCase().includes(q) ||
      (inv.id || '').toLowerCase().includes(q);
    const matchCurrency = !currencyFilter || inv.currency === currencyFilter;
    return matchSearch && matchCurrency;
  });

  const getData = (inv) => {
    let d = inv.extracted_data;
    if (typeof d === 'string') { try { d = JSON.parse(d); } catch { d = {}; } }
    return d || {};
  };

  return (
    <div className="invoices-page fade-in">
      <div className="invoices-header">
        <div>
          <h1 className="page-title">Invoices</h1>
          <p className="page-sub">{invoices.length} document{invoices.length !== 1 ? 's' : ''} processed</p>
        </div>
        <Link to="/" className="btn btn-primary">
          + Extract New
        </Link>
      </div>

      <div className="invoices-filters">
        <div className="search-wrap">
          <Search size={14} className="search-icon" />
          <input
            className="search-input"
            placeholder="Search by vendor, filename, ID..."
            value={search}
            onChange={e => setSearch(e.target.value)}
          />
        </div>
        <select
          className="filter-select"
          value={currencyFilter}
          onChange={e => setCurrencyFilter(e.target.value)}
        >
          <option value="">All Currencies</option>
          {currencies.map(c => <option key={c} value={c}>{c}</option>)}
        </select>
      </div>

      {loading ? (
        <div className="loading-state">
          <Loader2 size={24} className="spin text-accent" />
          <span className="text-dim">Loading invoices...</span>
        </div>
      ) : filtered.length === 0 ? (
        <div className="empty-state">
          <FileText size={40} className="text-dim" />
          <p className="text-dim">
            {invoices.length === 0 ? 'No invoices yet. Upload one to get started!' : 'No invoices match your search.'}
          </p>
          {invoices.length === 0 && (
            <Link to="/" className="btn btn-primary" style={{ marginTop: 16 }}>
              Extract First Invoice
            </Link>
          )}
        </div>
      ) : (
        <div className="invoices-table-wrap">
          <table className="invoices-table">
            <thead>
              <tr>
                <th>Vendor</th>
                <th>Invoice #</th>
                <th>Date</th>
                <th>Amount</th>
                <th>Confidence</th>
                <th>Status</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {filtered.map(inv => {
                const data = getData(inv);
                const invNum = data.invoice_number || inv.id?.slice(-8);
                const vendor = inv.vendor_name || data.vendor_name || '—';
                const amount = inv.total_amount ?? data.total_amount;
                const currency = inv.currency || data.currency || 'USD';
                const date = inv.invoice_date || data.invoice_date;
                const confidence = inv.confidence_score ?? data.confidence_score;

                return (
                  <tr key={inv.id} className="inv-row">
                    <td>
                      <div className="vendor-cell">
                        <div className="vendor-avatar">{vendor[0] || '?'}</div>
                        <div>
                          <div className="vendor-name">{vendor}</div>
                          <div className="vendor-filename mono">{inv.filename}</div>
                        </div>
                      </div>
                    </td>
                    <td className="mono">{invNum || '—'}</td>
                    <td>{date || '—'}</td>
                    <td>
                      {amount != null ? (
                        <span className="amount-cell mono">
                          {currency} {Number(amount).toLocaleString(undefined, { minimumFractionDigits: 2 })}
                        </span>
                      ) : '—'}
                    </td>
                    <td>
                      {confidence != null ? (
                        <ConfidenceBar score={confidence} />
                      ) : '—'}
                    </td>
                    <td>
                      {inv.is_duplicate ? (
                        <span className="badge badge-warning">
                          <AlertTriangle size={10} /> Duplicate
                        </span>
                      ) : (
                        <span className="badge badge-success">Extracted</span>
                      )}
                    </td>
                    <td>
                      <Link to={`/invoices/${inv.id}`} className="btn btn-ghost row-btn">
                        <ChevronRight size={14} />
                      </Link>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
