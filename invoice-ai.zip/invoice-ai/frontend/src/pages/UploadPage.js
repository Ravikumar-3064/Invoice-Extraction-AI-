import React, { useState, useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import { useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import { uploadInvoice, uploadBatch } from '../utils/api';
import {
  Upload, FileText, CheckCircle, AlertCircle, Loader2,
  ChevronRight, Zap, Shield, BarChart3, Clock
} from 'lucide-react';
import './UploadPage.css';

const FEATURES = [
  { icon: <Zap size={18} />, title: 'LLM-Powered', desc: 'Claude vision extracts every field with high accuracy' },
  { icon: <Shield size={18} />, title: 'Duplicate Detection', desc: 'SHA-256 hash deduplication prevents double-processing' },
  { icon: <BarChart3 size={18} />, title: 'Format Templates', desc: 'Learns invoice formats to speed up repeat extractions' },
  { icon: <Clock size={18} />, title: 'Batch Processing', desc: 'Upload up to 10 invoices simultaneously' },
];

function ConfidenceBadge({ score }) {
  const pct = Math.round(score * 100);
  const cls = score >= 0.8 ? 'badge-success' : score >= 0.6 ? 'badge-warning' : 'badge-error';
  return <span className={`badge ${cls}`}>{pct}% confidence</span>;
}

function FileCard({ file, status, result }) {
  return (
    <div className={`file-card ${status}`}>
      <div className="file-card-icon">
        {status === 'pending' && <FileText size={20} />}
        {status === 'processing' && <Loader2 size={20} className="spin" />}
        {status === 'done' && <CheckCircle size={20} className="text-green" />}
        {status === 'error' && <AlertCircle size={20} className="text-red" />}
      </div>
      <div className="file-card-info">
        <div className="file-card-name">{file.name}</div>
        <div className="file-card-meta mono">
          {(file.size / 1024).toFixed(1)} KB · {file.type.split('/')[1].toUpperCase()}
        </div>
        {result && result.is_duplicate && (
          <span className="badge badge-warning mt-4">Duplicate Detected</span>
        )}
        {result && result.extracted_data?.confidence_score && (
          <ConfidenceBadge score={result.extracted_data.confidence_score} />
        )}
        {result && result.extracted_data?.vendor_name && (
          <div className="file-card-vendor">{result.extracted_data.vendor_name}</div>
        )}
        {result && result.extracted_data?.total_amount != null && (
          <div className="file-card-amount">
            {result.extracted_data.currency} {result.extracted_data.total_amount?.toLocaleString()}
          </div>
        )}
      </div>
      {status === 'done' && result && (
        <a href={`/invoices/${result.id}`} className="btn btn-ghost file-card-btn">
          View <ChevronRight size={14} />
        </a>
      )}
    </div>
  );
}

export default function UploadPage() {
  const navigate = useNavigate();
  const [files, setFiles] = useState([]); // [{file, status, result}]
  const [processing, setProcessing] = useState(false);

  const onDrop = useCallback((accepted) => {
    const newFiles = accepted.map(f => ({ file: f, status: 'pending', result: null }));
    setFiles(prev => [...prev, ...newFiles]);
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: { 'image/jpeg': [], 'image/png': [], 'application/pdf': [] },
    maxSize: 10 * 1024 * 1024,
    maxFiles: 10,
    onDropRejected: (rej) => {
      rej.forEach(({ file, errors }) => {
        toast.error(`${file.name}: ${errors[0].message}`);
      });
    },
  });

  const processFiles = async () => {
    if (files.length === 0) return;
    setProcessing(true);

    const pending = files.filter(f => f.status === 'pending');

    if (pending.length === 1) {
      // Single file
      const idx = files.findIndex(f => f.status === 'pending');
      setFiles(prev => prev.map((f, i) => i === idx ? { ...f, status: 'processing' } : f));
      try {
        const result = await uploadInvoice(pending[0].file);
        setFiles(prev => prev.map((f, i) => i === idx ? { ...f, status: 'done', result } : f));
        toast.success(`Extracted: ${result.extracted_data?.vendor_name || result.filename}`);
      } catch (err) {
        setFiles(prev => prev.map((f, i) => i === idx ? { ...f, status: 'error' } : f));
        toast.error(err.response?.data?.detail || 'Extraction failed');
      }
    } else {
      // Batch
      setFiles(prev => prev.map(f => f.status === 'pending' ? { ...f, status: 'processing' } : f));
      try {
        const result = await uploadBatch(pending.map(p => p.file));
        const results = result.results;
        setFiles(prev => {
          let ri = 0;
          return prev.map(f => {
            if (f.status !== 'processing') return f;
            const r = results[ri++];
            return { ...f, status: r?.status === 'error' ? 'error' : 'done', result: r };
          });
        });
        toast.success(`Batch complete: ${result.successful}/${result.total} succeeded`);
      } catch (err) {
        setFiles(prev => prev.map(f => f.status === 'processing' ? { ...f, status: 'error' } : f));
        toast.error('Batch processing failed');
      }
    }

    setProcessing(false);
  };

  const pendingCount = files.filter(f => f.status === 'pending').length;
  const doneCount = files.filter(f => f.status === 'done').length;

  return (
    <div className="upload-page fade-in">
      <div className="upload-hero">
        <div className="upload-hero-label mono">AI-POWERED EXTRACTION</div>
        <h1 className="upload-hero-title">
          Turn Invoices Into<br />
          <span className="gradient-text">Structured Data</span>
        </h1>
        <p className="upload-hero-sub">
          Upload JPG, PNG, or PDF invoices. Claude Vision extracts every field —
          vendor, amounts, line items, dates — in seconds.
        </p>
      </div>

      <div className="upload-features">
        {FEATURES.map((f, i) => (
          <div key={i} className="upload-feature-item">
            <div className="feature-icon">{f.icon}</div>
            <div>
              <div className="feature-title">{f.title}</div>
              <div className="feature-desc">{f.desc}</div>
            </div>
          </div>
        ))}
      </div>

      <div
        {...getRootProps()}
        className={`dropzone ${isDragActive ? 'active' : ''} ${processing ? 'disabled' : ''}`}
      >
        <input {...getInputProps()} />
        <div className="dropzone-inner">
          <div className="dropzone-icon">
            <Upload size={32} />
          </div>
          <div className="dropzone-title">
            {isDragActive ? 'Drop to extract →' : 'Drop invoices here'}
          </div>
          <div className="dropzone-sub">
            or <span className="text-accent">browse files</span> · JPG, PNG, PDF up to 10MB · Batch up to 10 files
          </div>
        </div>
      </div>

      {files.length > 0 && (
        <div className="file-list fade-in">
          <div className="file-list-header">
            <div className="file-list-title">
              {files.length} file{files.length > 1 ? 's' : ''}
              {doneCount > 0 && <span className="text-green"> · {doneCount} extracted</span>}
            </div>
            <button className="btn btn-ghost" onClick={() => setFiles([])}>Clear</button>
          </div>

          <div className="file-cards">
            {files.map((item, i) => (
              <FileCard key={i} file={item.file} status={item.status} result={item.result} />
            ))}
          </div>

          {pendingCount > 0 && (
            <button
              className="btn btn-primary extract-btn"
              onClick={processFiles}
              disabled={processing}
            >
              {processing ? (
                <><Loader2 size={16} className="spin" /> Processing...</>
              ) : (
                <><Zap size={16} /> Extract {pendingCount} Invoice{pendingCount > 1 ? 's' : ''}</>
              )}
            </button>
          )}

          {doneCount > 0 && !processing && (
            <button className="btn btn-ghost view-all-btn" onClick={() => navigate('/invoices')}>
              View All Invoices <ChevronRight size={14} />
            </button>
          )}
        </div>
      )}

      <div className="upload-hint">
        <Shield size={13} className="text-dim" />
        <span className="text-dim">Files processed via Claude Vision API · Data stored securely in Supabase</span>
      </div>
    </div>
  );
}
