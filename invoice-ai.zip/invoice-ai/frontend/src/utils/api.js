import axios from 'axios';

const BASE_URL = process.env.REACT_APP_API_URL || '';

const api = axios.create({
  baseURL: BASE_URL,
  timeout: 120000, // 2min for large files
});

export const uploadInvoice = async (file, onProgress) => {
  const form = new FormData();
  form.append('file', file);
  const { data } = await api.post('/api/invoices/upload', form, {
    headers: { 'Content-Type': 'multipart/form-data' },
    onUploadProgress: e => onProgress && onProgress(Math.round((e.loaded * 100) / e.total)),
  });
  return data;
};

export const uploadBatch = async (files, onProgress) => {
  const form = new FormData();
  files.forEach(f => form.append('files', f));
  const { data } = await api.post('/api/invoices/batch', form, {
    headers: { 'Content-Type': 'multipart/form-data' },
    onUploadProgress: e => onProgress && onProgress(Math.round((e.loaded * 100) / e.total)),
  });
  return data;
};

export const getInvoices = async (filters = {}) => {
  const params = new URLSearchParams();
  if (filters.vendor) params.append('vendor', filters.vendor);
  if (filters.currency) params.append('currency', filters.currency);
  const { data } = await api.get(`/api/invoices?${params}`);
  return data;
};

export const getInvoice = async (id) => {
  const { data } = await api.get(`/api/invoices/${id}`);
  return data;
};

export const getAnalytics = async () => {
  const { data } = await api.get('/api/analytics');
  return data;
};

export const getHealth = async () => {
  const { data } = await api.get('/health');
  return data;
};

export const getTemplates = async () => {
  const { data } = await api.get('/api/templates');
  return data;
};
