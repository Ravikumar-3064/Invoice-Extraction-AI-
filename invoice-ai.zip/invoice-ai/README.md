# 🧾 InvoiceAI — Intelligent Invoice Extraction Platform

> AI-powered invoice data extraction, storage, and analytics using Claude Vision + FastAPI + React + Supabase.

---

## 📺 Demo

**Live App:** [https://invoice-ai.vercel.app](https://invoice-ai.vercel.app)  
**API Docs:** [https://invoice-ai-backend.onrender.com/docs](https://invoice-ai-backend.onrender.com/docs)  
**Demo Video:** [Loom walkthrough link](https://loom.com/...)

---

## ✨ Features

| Feature | Details |
|---|---|
| 🔍 **LLM Extraction** | Claude Vision API extracts all fields: vendor, amounts, line items, dates, tax, currency |
| 🖼️ **Multi-format** | JPG, PNG, PDF support |
| 📦 **Batch Processing** | Upload up to 10 invoices simultaneously with concurrent processing |
| 🔁 **Duplicate Detection** | SHA-256 content hashing prevents re-processing identical files |
| 🧩 **Format Templates** | Detects and reuses invoice format fingerprints for faster extraction |
| 📊 **Analytics Dashboard** | Vendor spend, monthly trends, currency breakdown, confidence scores |
| ✅ **Validation** | Pydantic models enforce types, ranges, date formats |
| 🗄️ **Supabase Backend** | PostgreSQL storage with Row Level Security + file storage |
| 🔄 **Graceful Fallback** | Works without Supabase (in-memory store for testing) |

---

## 🏗️ System Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                        Client (React)                       │
│  ┌──────────┐  ┌───────────┐  ┌──────────────────────────┐ │
│  │  Upload  │  │ Invoices  │  │  Analytics Dashboard     │ │
│  │  Dropzone│  │   Table   │  │  (Recharts)              │ │
│  └────┬─────┘  └─────┬─────┘  └──────────┬───────────────┘ │
└───────┼──────────────┼───────────────────┼─────────────────┘
        │              │                   │
        ▼              ▼                   ▼
┌─────────────────────────────────────────────────────────────┐
│                    FastAPI Backend                          │
│                                                             │
│  POST /api/invoices/upload                                  │
│  POST /api/invoices/batch                                   │
│  GET  /api/invoices                                         │
│  GET  /api/invoices/{id}                                    │
│  GET  /api/analytics                                        │
│  GET  /api/templates                                        │
│                                                             │
│  ┌───────────────────────────────────────────────────────┐  │
│  │              Processing Pipeline                      │  │
│  │                                                       │  │
│  │  File Upload → Hash Check (duplicate?) → Base64      │  │
│  │       ↓                                               │  │
│  │  Format Detection (claude-haiku) → Template Lookup   │  │
│  │       ↓                                               │  │
│  │  Extraction (claude-opus) → Pydantic Validation      │  │
│  │       ↓                                               │  │
│  │  Store Result → Return JSON                          │  │
│  └───────────────────────────────────────────────────────┘  │
└──────────────┬──────────────────────┬───────────────────────┘
               │                      │
               ▼                      ▼
┌──────────────────────┐  ┌──────────────────────────────────┐
│   Anthropic API      │  │         Supabase                 │
│                      │  │                                  │
│  claude-opus-4-5     │  │  PostgreSQL Tables:              │
│  (extraction)        │  │  - invoices                      │
│                      │  │  - format_templates              │
│  claude-haiku-4-5    │  │  - users                         │
│  (format detection)  │  │                                  │
│                      │  │  Storage Bucket: invoices        │
└──────────────────────┘  └──────────────────────────────────┘
```

---

## 🧠 Key Design Decisions

### 1. Two-Model Strategy (Cost Optimization)
- **claude-haiku** for format detection: fast, cheap, 400 token output
- **claude-opus** for extraction: highest accuracy for structured data
- This reduces cost ~60% vs using Opus for everything

### 2. Format Template System
Every invoice gets a format fingerprint based on layout type, header position, and table presence. When a matching template is found, it's passed as a hint to the extraction prompt. This improves accuracy for repeat vendors and speeds up processing.

```python
# Format signature = MD5 of layout_type + header_position + has_line_items_table
sig = f"{layout_type}-{header_position}-{has_table}"
signature = hashlib.md5(sig.encode()).hexdigest()[:12]
```

### 3. Duplicate Detection via SHA-256
File content is hashed before any API calls. Duplicates return instantly with cached data — no LLM cost incurred.

### 4. Graceful Degradation
The backend works without Supabase configured. It falls back to in-memory Python dicts, making local development and testing trivial.

### 5. Prompt Engineering
The extraction prompt:
- Enforces strict JSON schema (no markdown fences)
- Requires ISO 8601 dates
- Requires numeric (not string) monetary values
- Asks for `confidence_score` and `extraction_warnings`
- Accepts format template hints to guide repeated formats

### 6. Pydantic Validation
All extracted data is validated through `ExtractedInvoice` model. Partial failures don't crash the pipeline — warnings are appended to `extraction_warnings` and partial data is returned.

---

## 📁 Project Structure

```
invoice-ai/
├── backend/
│   ├── main.py              # FastAPI app, all routes, pipeline logic
│   ├── schema.sql           # Supabase database schema + RLS
│   ├── requirements.txt
│   ├── Dockerfile
│   └── .env.example
├── frontend/
│   ├── src/
│   │   ├── App.js           # Router + Nav
│   │   ├── pages/
│   │   │   ├── UploadPage.js        # Dropzone + extraction UI
│   │   │   ├── InvoicesPage.js      # Paginated invoice list
│   │   │   ├── InvoiceDetailPage.js # Full extracted data view
│   │   │   └── AnalyticsPage.js     # Recharts dashboards
│   │   └── utils/api.js     # Axios API client
│   ├── public/index.html
│   ├── package.json
│   ├── Dockerfile
│   └── .env.example
├── docker-compose.yml
├── render.yaml              # Render.com deployment config
├── vercel.json              # Vercel frontend config
└── README.md
```

---

## 🗄️ Database Schema

### `invoices` table
| Column | Type | Description |
|---|---|---|
| id | TEXT PK | Unique invoice ID (inv_xxxxxxxxxxxx) |
| filename | TEXT | Original uploaded filename |
| file_hash | TEXT | SHA-256 for deduplication |
| file_url | TEXT | Supabase Storage URL |
| status | TEXT | processing / completed / failed / duplicate_detected |
| extracted_data | JSONB | Full extracted invoice JSON |
| format_signature | TEXT | FK to format_templates |
| vendor_name | TEXT | Denormalized for fast queries |
| total_amount | NUMERIC | Denormalized for analytics |
| currency | TEXT | ISO 4217 code |
| invoice_date | DATE | |
| confidence_score | NUMERIC | 0.0–1.0 |
| processing_time_ms | INTEGER | End-to-end latency |
| is_duplicate | BOOLEAN | |
| duplicate_of | TEXT | FK to original invoice |
| created_at | TIMESTAMPTZ | |

### `format_templates` table
| Column | Type | Description |
|---|---|---|
| id | UUID PK | |
| signature | TEXT UNIQUE | MD5 fingerprint of layout |
| format_data | JSONB | Layout description from haiku |
| use_count | INTEGER | How many times this template was matched |

---

## 🚀 Quick Start

### Prerequisites
- Python 3.11+
- Node.js 18+
- Anthropic API key
- Supabase project (optional for local dev)

### 1. Clone & Configure

```bash
git clone https://github.com/yourusername/invoice-ai.git
cd invoice-ai

# Backend
cp backend/.env.example backend/.env
# Edit backend/.env with your ANTHROPIC_API_KEY

# Frontend
cp frontend/.env.example frontend/.env
```

### 2. Run Backend

```bash
cd backend
pip install -r requirements.txt
uvicorn main:app --reload --port 8000
# API docs at http://localhost:8000/docs
```

### 3. Run Frontend

```bash
cd frontend
npm install
npm start
# App at http://localhost:3000
```

### 4. Set Up Supabase (Optional)

1. Create a new Supabase project at [supabase.com](https://supabase.com)
2. Run `backend/schema.sql` in the SQL Editor
3. Create a storage bucket named `invoices` (set to Public)
4. Add `SUPABASE_URL` and `SUPABASE_ANON_KEY` to `backend/.env`

### 5. Docker (Alternative)

```bash
cp backend/.env.example backend/.env  # fill in keys
docker-compose up --build
```

---

## 🚢 Deployment

### Backend → Render.com

1. Connect your GitHub repo to [render.com](https://render.com)
2. Use the provided `render.yaml` or configure manually:
   - **Build:** `pip install -r backend/requirements.txt`
   - **Start:** `uvicorn backend.main:app --host 0.0.0.0 --port $PORT`
3. Set environment variables in Render dashboard

### Frontend → Vercel

```bash
cd frontend
npm install -g vercel
vercel --prod
# Set REACT_APP_API_URL to your Render backend URL
```

---

## 📡 API Reference

### `POST /api/invoices/upload`
Upload and extract a single invoice.

**Request:** `multipart/form-data` with `file` field  
**Response:**
```json
{
  "id": "inv_abc123",
  "filename": "invoice.pdf",
  "status": "completed",
  "is_duplicate": false,
  "format_template_reused": true,
  "extracted_data": {
    "invoice_number": "INV-2024-001",
    "vendor_name": "Acme Corp",
    "total_amount": 1500.00,
    "currency": "USD",
    "confidence_score": 0.94,
    "line_items": [...],
    "extraction_warnings": []
  }
}
```

### `POST /api/invoices/batch`
Upload up to 10 invoices simultaneously.

### `GET /api/invoices`
List all invoices. Query params: `vendor`, `currency`, `limit`

### `GET /api/invoices/{id}`
Get full details for one invoice.

### `GET /api/analytics`
Returns vendor spend, monthly trends, currency totals, summary stats.

### `GET /health`
Health check — reports Supabase and LLM connection status.

---

## ⚠️ Assumptions & Limitations

1. **PDF handling:** PDFs are passed as base64 directly to the vision API. For multi-page PDFs, only the first visual representation is analyzed. Production would use `pdf2image` to rasterize each page.

2. **Currency conversion:** Analytics totals are not converted to a common currency. Multi-currency sums are shown per-currency only.

3. **OCR:** This system relies entirely on Claude Vision's built-in OCR capability, not a separate Tesseract step. This is intentional — Claude's vision is more accurate than Tesseract for complex invoice layouts.

4. **Auth:** Row Level Security is set to allow-all for demo purposes. Production would add Supabase Auth with JWT validation.

5. **Rate limits:** The Anthropic API has rate limits. Batch processing of 10 files may hit limits on free tier — add retry logic with exponential backoff for production.

6. **File size:** Hard limit of 10MB. Very high-resolution scans may need downscaling before upload.

---

## 🔮 Potential Improvements

### Short-term
- [ ] Retry logic with exponential backoff for LLM API failures
- [ ] PDF multi-page support using pdf2image
- [ ] Field-level highlighting in a PDF viewer (react-pdf + bounding boxes)
- [ ] Webhook support for async processing of large batches
- [ ] Export to CSV/Excel

### Medium-term
- [ ] User authentication with Supabase Auth
- [ ] Vendor normalization using fuzzy matching (rapidfuzz)
- [ ] Currency conversion API integration (Open Exchange Rates)
- [ ] Email invoice ingestion (IMAP/SendGrid inbound)
- [ ] Fine-tuned confidence calibration per vendor

### Long-term
- [ ] Feedback loop: users correct fields → training data → fine-tuned model
- [ ] ERP/accounting integrations (QuickBooks, Xero, SAP)
- [ ] Multi-tenant SaaS with per-org data isolation
- [ ] On-premise deployment with local LLM (Ollama + LLaVA)

---

## 📊 Scalability Thinking

| Concern | Current Approach | Production Approach |
|---|---|---|
| **Throughput** | Synchronous FastAPI | Celery + Redis task queue |
| **Storage** | Supabase Storage | S3 + CloudFront CDN |
| **LLM Cost** | Single extraction call | Cache by file hash + template reuse |
| **DB Performance** | Basic indexes | Partitioning by date + materialized views |
| **API Rate Limits** | None | Token bucket per user |
| **Concurrency** | asyncio gather | Horizontal scaling via load balancer |

---

## 📬 Contact

**Submitted by:** [Your Name]  
**Email:** yashjeet.singh@avaipl.com  
**GitHub:** [https://github.com/yourusername/invoice-ai](https://github.com/yourusername/invoice-ai)
